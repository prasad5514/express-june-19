const expresss=require("express");

const authersrouter=expresss.Router();

function routerauthers(nav){

    var authersdet=[
        {
            name:"joseph barbera",
            details:"joseph barbera",
            img:"barbera.jpeg"
        },
        {
            name:"jk rowling",
            details:"jk rowling",
            img:"jkrowling.jpeg"
        },
        {
            name:"vykam muhammed basheer",
            details:"vykam muhammed basheer",
            img:"bhasher.jpeg"
        }
    ]

    authersrouter.get("/",function(req,res){
        res.render("authers",{
            nav,
            title:'authers',
            authersdet
        });
    });
    return authersrouter;
}
module.exports=routerauthers;

// <%=for(i=0;i<autdet.length;i++){%>
// <h3><%=autdet[i].name%></h3>

// <%}%>