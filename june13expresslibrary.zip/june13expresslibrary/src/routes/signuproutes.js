const expresss=require("express");

const signuprouter=expresss.Router();

function routersignup(nav){
    signuprouter.get("/",function(req,res){
        res.render("signup",{
            nav,
            title:'library'
        });
    });
    return signuprouter;
}
module.exports=routersignup;